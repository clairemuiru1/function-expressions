function car("benz") {
    if (car === 'benz') {
        return`benz is expensive`
    }
    else if(car ==='toyota'){
        return`toyota is affordable`
    }
}

function name(params) {
    
}